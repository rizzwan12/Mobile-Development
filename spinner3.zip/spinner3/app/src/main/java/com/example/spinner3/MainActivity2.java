package com.example.spinner3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.net.URI;

public class MainActivity2 extends AppCompatActivity {
    private TextView t1;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        t1=(TextView) findViewById(R.id.textView1);
        Bundle b=getIntent().getExtras();
        String n=b.getString("num");
        t1.setText(n);
        builder = new AlertDialog.Builder(this);
        AlertDialog alert = builder.create();

        //Setting the title manually
        alert.setTitle("hello.....");
        alert.show();
    }
}